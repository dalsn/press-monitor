self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4a9f8e261631234ffd9b",
    "url": "/css/app.1c1b8498.css"
  },
  {
    "revision": "4b643e3b1eabc08601fe",
    "url": "/css/chunk-9d0bdc28.f5dadd15.css"
  },
  {
    "revision": "54f91081e3fd70cb3993",
    "url": "/css/explore.e9a24489.css"
  },
  {
    "revision": "1e60a0046b5d41396bb9",
    "url": "/css/index.615d695d.css"
  },
  {
    "revision": "040df912a795d4a63b44",
    "url": "/css/state.39fb2a43.css"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/favicon.png"
  },
  {
    "revision": "fd1b4518dcb7ff1b4baa683e5633c5e3",
    "url": "/favicon.svg"
  },
  {
    "revision": "7919768a1ecd2478c31bf3c33d4d519f",
    "url": "/img/blackdot.7919768a.png"
  },
  {
    "revision": "461c1ff5ab84ce519ead7a9ae717e652",
    "url": "/img/courtcases.461c1ff5.svg"
  },
  {
    "revision": "8c7d1b7272cc7d757610295d9e150f48",
    "url": "/img/pfm-logo-white.8c7d1b72.png"
  },
  {
    "revision": "d0e7be1353ae8a7a56ab7062f9aae9b3",
    "url": "/img/scale.d0e7be13.svg"
  },
  {
    "revision": "a04d174fa76cd012b9fb97387ff4eb9b",
    "url": "/img/search-by-algolia.a04d174f.svg"
  },
  {
    "revision": "47ad2cecbb9732589f641ea23bd88797",
    "url": "/img/topic.47ad2cec.svg"
  },
  {
    "revision": "f7756ee5db5011817e214b31b07e2fe0",
    "url": "/index.html"
  },
  {
    "revision": "9335dae5e6e09a4221e0",
    "url": "/js/about.215aa8ba.js"
  },
  {
    "revision": "4a9f8e261631234ffd9b",
    "url": "/js/app.ef64e877.js"
  },
  {
    "revision": "7ef1f0375074266e9d74",
    "url": "/js/chunk-54b95a4c.dd8972b9.js"
  },
  {
    "revision": "4b643e3b1eabc08601fe",
    "url": "/js/chunk-9d0bdc28.886f8ccc.js"
  },
  {
    "revision": "9e0bad9557f3ad8c820d",
    "url": "/js/chunk-vendors.30c67c83.js"
  },
  {
    "revision": "5205efcb2d4199606b23811f0ad8446e",
    "url": "/js/countrymap.dev.js"
  },
  {
    "revision": "18c23d3bb8e57f4d5f9f",
    "url": "/js/datapoint.a3aa3c88.js"
  },
  {
    "revision": "0ae4dc4b3069cd80c952",
    "url": "/js/datapoint~explore~index.37b23fee.js"
  },
  {
    "revision": "54f91081e3fd70cb3993",
    "url": "/js/explore.649cabff.js"
  },
  {
    "revision": "1e60a0046b5d41396bb9",
    "url": "/js/index.304f3f50.js"
  },
  {
    "revision": "95bec3cf40c9b485c259e60b740e1f07",
    "url": "/js/mapdata.nig.js"
  },
  {
    "revision": "040df912a795d4a63b44",
    "url": "/js/state.dc773a7b.js"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/logo.png"
  },
  {
    "revision": "01ac19ce9c7e42f4db216b96773b4f33",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);