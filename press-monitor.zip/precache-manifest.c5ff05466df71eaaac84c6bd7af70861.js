self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a1eb266511fec96cee56",
    "url": "/css/app.0e01cfce.css"
  },
  {
    "revision": "962d16cd31e133d2facc",
    "url": "/css/chunk-214343c4.f5dadd15.css"
  },
  {
    "revision": "3d726e87c73916070c1a",
    "url": "/css/explore.17769b81.css"
  },
  {
    "revision": "2438519fc4b22d8f3b08",
    "url": "/css/index.6f0dc4ef.css"
  },
  {
    "revision": "45eec4c679658470306f",
    "url": "/css/state.5f92d0fa.css"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/favicon.png"
  },
  {
    "revision": "fd1b4518dcb7ff1b4baa683e5633c5e3",
    "url": "/favicon.svg"
  },
  {
    "revision": "273a9c1367741bc2573781c130d3864e",
    "url": "/img/accused.273a9c13.svg"
  },
  {
    "revision": "b57ae4a69c1e6e3836e06f242c78ef16",
    "url": "/img/acja.b57ae4a6.svg"
  },
  {
    "revision": "d270dd24ceb406d1cc57e20e046af630",
    "url": "/img/amount.d270dd24.svg"
  },
  {
    "revision": "7919768a1ecd2478c31bf3c33d4d519f",
    "url": "/img/blackdot.7919768a.png"
  },
  {
    "revision": "461c1ff5ab84ce519ead7a9ae717e652",
    "url": "/img/courtcases.461c1ff5.svg"
  },
  {
    "revision": "287eaab310c97b9c0dbcc165bd2ee666",
    "url": "/img/date.287eaab3.svg"
  },
  {
    "revision": "29e08470ad9e5d9189145a5dedd54c5e",
    "url": "/img/decision.29e08470.svg"
  },
  {
    "revision": "0278f91ad30b4f99fd51e423fba85af5",
    "url": "/img/judge.0278f91a.svg"
  },
  {
    "revision": "f139828769ac2dd7121d018a56aec934",
    "url": "/img/pm-logo-white.f1398287.png"
  },
  {
    "revision": "3f014a948e69c7dc9475e0e026a5fde3",
    "url": "/img/pm-logo.3f014a94.png"
  },
  {
    "revision": "d0e7be1353ae8a7a56ab7062f9aae9b3",
    "url": "/img/scale.d0e7be13.svg"
  },
  {
    "revision": "a04d174fa76cd012b9fb97387ff4eb9b",
    "url": "/img/search-by-algolia.a04d174f.svg"
  },
  {
    "revision": "53a2bd90b38b74e26241cb30bc48d1cd",
    "url": "/img/summary.53a2bd90.svg"
  },
  {
    "revision": "47ad2cecbb9732589f641ea23bd88797",
    "url": "/img/topic.47ad2cec.svg"
  },
  {
    "revision": "a9719ce32e12ea69df9c39bb2b107631",
    "url": "/index.html"
  },
  {
    "revision": "9c2f2a48972e107f2044",
    "url": "/js/about.a35b5fe3.js"
  },
  {
    "revision": "a1eb266511fec96cee56",
    "url": "/js/app.36c3c6e3.js"
  },
  {
    "revision": "962d16cd31e133d2facc",
    "url": "/js/chunk-214343c4.200a6322.js"
  },
  {
    "revision": "9eec3738b5d5400bbb10",
    "url": "/js/chunk-558bf1b3.96410cce.js"
  },
  {
    "revision": "b6bd5b6209ea8b34e40c",
    "url": "/js/chunk-vendors.44e85e14.js"
  },
  {
    "revision": "0e238b8e398d8e921a4a",
    "url": "/js/datapoint.571798b2.js"
  },
  {
    "revision": "2e97da85ce6073030a26",
    "url": "/js/datapoint~explore.f18cec7a.js"
  },
  {
    "revision": "3d726e87c73916070c1a",
    "url": "/js/explore.d7314840.js"
  },
  {
    "revision": "2438519fc4b22d8f3b08",
    "url": "/js/index.3bf565d3.js"
  },
  {
    "revision": "45eec4c679658470306f",
    "url": "/js/state.9ddbe500.js"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/logo.png"
  },
  {
    "revision": "339cf474babf29457ca1755a0abe28d8",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);