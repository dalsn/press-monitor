self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba53bf430632bea0fb29",
    "url": "/css/app.9edcc0b2.css"
  },
  {
    "revision": "15ec7c0194c4e8eadc6b",
    "url": "/css/chunk-45d54e79.f5dadd15.css"
  },
  {
    "revision": "f96bdaba5a60692b49c4",
    "url": "/css/explore.04782471.css"
  },
  {
    "revision": "dcdfb08dc46f7ab6a760",
    "url": "/css/index.183f1096.css"
  },
  {
    "revision": "040df912a795d4a63b44",
    "url": "/css/state.39fb2a43.css"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/favicon.png"
  },
  {
    "revision": "fd1b4518dcb7ff1b4baa683e5633c5e3",
    "url": "/favicon.svg"
  },
  {
    "revision": "273a9c1367741bc2573781c130d3864e",
    "url": "/img/accused.273a9c13.svg"
  },
  {
    "revision": "b57ae4a69c1e6e3836e06f242c78ef16",
    "url": "/img/acja.b57ae4a6.svg"
  },
  {
    "revision": "d270dd24ceb406d1cc57e20e046af630",
    "url": "/img/amount.d270dd24.svg"
  },
  {
    "revision": "7919768a1ecd2478c31bf3c33d4d519f",
    "url": "/img/blackdot.7919768a.png"
  },
  {
    "revision": "461c1ff5ab84ce519ead7a9ae717e652",
    "url": "/img/courtcases.461c1ff5.svg"
  },
  {
    "revision": "287eaab310c97b9c0dbcc165bd2ee666",
    "url": "/img/date.287eaab3.svg"
  },
  {
    "revision": "29e08470ad9e5d9189145a5dedd54c5e",
    "url": "/img/decision.29e08470.svg"
  },
  {
    "revision": "0278f91ad30b4f99fd51e423fba85af5",
    "url": "/img/judge.0278f91a.svg"
  },
  {
    "revision": "f139828769ac2dd7121d018a56aec934",
    "url": "/img/pm-logo-white.f1398287.png"
  },
  {
    "revision": "3f014a948e69c7dc9475e0e026a5fde3",
    "url": "/img/pm-logo.3f014a94.png"
  },
  {
    "revision": "d0e7be1353ae8a7a56ab7062f9aae9b3",
    "url": "/img/scale.d0e7be13.svg"
  },
  {
    "revision": "a04d174fa76cd012b9fb97387ff4eb9b",
    "url": "/img/search-by-algolia.a04d174f.svg"
  },
  {
    "revision": "53a2bd90b38b74e26241cb30bc48d1cd",
    "url": "/img/summary.53a2bd90.svg"
  },
  {
    "revision": "47ad2cecbb9732589f641ea23bd88797",
    "url": "/img/topic.47ad2cec.svg"
  },
  {
    "revision": "30e1c83cad9c3842087cf2291a6d6264",
    "url": "/index.html"
  },
  {
    "revision": "4f6bf5c088852d6722e5",
    "url": "/js/about.724bbddd.js"
  },
  {
    "revision": "ba53bf430632bea0fb29",
    "url": "/js/app.29c7e7a4.js"
  },
  {
    "revision": "15ec7c0194c4e8eadc6b",
    "url": "/js/chunk-45d54e79.e5ea674a.js"
  },
  {
    "revision": "02f4cd3450cc7ee6f6a2",
    "url": "/js/chunk-47a798a2.b72028a7.js"
  },
  {
    "revision": "9e0bad9557f3ad8c820d",
    "url": "/js/chunk-vendors.30c67c83.js"
  },
  {
    "revision": "5205efcb2d4199606b23811f0ad8446e",
    "url": "/js/countrymap.dev.js"
  },
  {
    "revision": "18c23d3bb8e57f4d5f9f",
    "url": "/js/datapoint.a3aa3c88.js"
  },
  {
    "revision": "0ae4dc4b3069cd80c952",
    "url": "/js/datapoint~explore~index.37b23fee.js"
  },
  {
    "revision": "f96bdaba5a60692b49c4",
    "url": "/js/explore.e5e2a080.js"
  },
  {
    "revision": "dcdfb08dc46f7ab6a760",
    "url": "/js/index.cbc31297.js"
  },
  {
    "revision": "12de231bf5baa9ca71d8752680413824",
    "url": "/js/mapdata.nig.js"
  },
  {
    "revision": "040df912a795d4a63b44",
    "url": "/js/state.dc773a7b.js"
  },
  {
    "revision": "869edc625a2021ae16ad511b6af7d971",
    "url": "/logo.png"
  },
  {
    "revision": "339cf474babf29457ca1755a0abe28d8",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);